package modulo4;

public class PrimeiraClasse {

	public static void main(String[] args) {
		System.out.println(" Hello Word! "); // Ol� Mundo

	}

}
